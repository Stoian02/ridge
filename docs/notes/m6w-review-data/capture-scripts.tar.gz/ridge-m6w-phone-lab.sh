#!/usr/bin/env bash
set -euo pipefail
lab_round="${1:?round}"
[[ "$lab_round" =~ ^[0-9]+$ ]]
lab_out="/tmp/ridge-m6w-phone-lab/$lab_round"
mkdir -p "$lab_out"
if pgrep -x godot >/dev/null || adb -s 41374bac shell pidof com.ridge.game >/dev/null; then
  echo 'Game is running; will not overlap.'
  exit 1
fi
adb -s 41374bac shell 'run-as com.ridge.game sha256sum files/save.json; dumpsys battery | grep temperature; dumpsys thermalservice | grep "Thermal Status:"' > "$lab_out/before.txt"
adb -s 41374bac shell run-as com.ridge.game tee files/water_acceptance < /tmp/ridge-m6w-phone-lab.json >/dev/null
lab_since=$(adb -s 41374bac shell "date '+%m-%d %H:%M:%S.000'" | tr -d '\r')
adb -s 41374bac logcat -T "$lab_since" -v epoch -s godot:V AndroidRuntime:E > "$lab_out/logcat.txt" 2>&1 &
lab_log_pid=$!
trap 'kill "$lab_log_pid" 2>/dev/null || true' EXIT
adb -s 41374bac shell monkey -p com.ridge.game -c android.intent.category.LAUNCHER 1 >/dev/null
lab_done=false
for lab_poll in $(seq 1 45); do
  if rg -q 'SCRIPT ERROR|ERROR:|FATAL EXCEPTION|more than 1 mm|stale' "$lab_out/logcat.txt"; then
    echo 'Lab failed. Inspect retained log.'
    exit 1
  fi
  if rg -q 'wave GPU drawn-triangle parity' "$lab_out/logcat.txt"; then
    lab_done=true
    break
  fi
  sleep 1
done
[[ "$lab_done" == true ]]
sleep 2
adb -s 41374bac shell 'run-as com.ridge.game sha256sum files/save.json; dumpsys battery | grep temperature; dumpsys thermalservice | grep "Thermal Status:"' > "$lab_out/after.txt"
if adb -s 41374bac shell pidof com.ridge.game >/dev/null; then
  echo 'Lab did not exit.'
  exit 1
fi
echo "Phone lab complete: $lab_out"

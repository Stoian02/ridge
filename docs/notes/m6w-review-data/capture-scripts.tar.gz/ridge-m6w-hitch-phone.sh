#!/usr/bin/env bash
set -euo pipefail
hitch_label="${1:?label}"
hitch_config="${2:?local JSON options}"
hitch_duration="${3:-70s}"
[[ "$hitch_label" =~ ^[a-z0-9_-]+$ ]]
hitch_dir="/tmp/ridge-m6w-hitch/$hitch_label"
mkdir -p "$hitch_dir"
if pgrep -x godot >/dev/null || adb -s 41374bac shell pidof com.ridge.game >/dev/null; then
  echo 'Game or desktop Godot is active; refusing to overlap.'
  exit 1
fi
adb -s 41374bac shell 'dumpsys battery | grep temperature; dumpsys thermalservice | grep "Thermal Status:"; run-as com.ridge.game sha256sum files/save.json' > "$hitch_dir/before.txt"
adb -s 41374bac exec-out run-as com.ridge.game cat files/save.json > "$hitch_dir/save-before.json"
cp "$hitch_config" "$hitch_dir/options.json"
adb -s 41374bac shell run-as com.ridge.game tee files/water_acceptance < "$hitch_config" >/dev/null
hitch_since=$(adb -s 41374bac shell "date '+%m-%d %H:%M:%S.000'" | tr -d '\r')
adb -s 41374bac logcat -T "$hitch_since" -v epoch -s godot:V AndroidRuntime:E > "$hitch_dir/logcat.txt" 2>&1 &
hitch_log_pid=$!
trap 'kill "$hitch_log_pid" 2>/dev/null || true' EXIT
adb -s 41374bac shell perfetto --txt -c - -o "/data/misc/perfetto-traces/ridge-$hitch_label.pftrace" < /tmp/ridge-m6w-hitch-trace.pbtxt > "$hitch_dir/perfetto.txt" 2>&1 &
hitch_perfetto_pid=$!
adb -s 41374bac shell monkey -p com.ridge.game -c android.intent.category.LAUNCHER 1 >/dev/null
hitch_done=false
for hitch_poll in $(seq 1 180); do
  if rg -q 'water acceptance done:' "$hitch_dir/logcat.txt"; then
    hitch_done=true
    break
  fi
  if rg -q 'SCRIPT ERROR|FATAL EXCEPTION' "$hitch_dir/logcat.txt"; then
    echo 'Diagnostic failed; retained log needs review.'
    exit 1
  fi
  sleep 2
done
[[ "$hitch_done" == true ]]
wait "$hitch_perfetto_pid"
adb -s 41374bac pull "/data/misc/perfetto-traces/ridge-$hitch_label.pftrace" "$hitch_dir/system.pftrace"
adb -s 41374bac exec-out run-as com.ridge.game tar -cf - files/water_acceptance_results > "$hitch_dir/results.tar"
mkdir -p "$hitch_dir/results"
tar -xf "$hitch_dir/results.tar" --strip-components=2 -C "$hitch_dir/results"
adb -s 41374bac shell 'dumpsys battery | grep temperature; dumpsys thermalservice | grep "Thermal Status:"; run-as com.ridge.game sha256sum files/save.json' > "$hitch_dir/after.txt"
adb -s 41374bac exec-out run-as com.ridge.game cat files/save.json > "$hitch_dir/save-after.json"
cmp "$hitch_dir/save-before.json" "$hitch_dir/save-after.json"
echo "Hitch capture complete: $hitch_dir"

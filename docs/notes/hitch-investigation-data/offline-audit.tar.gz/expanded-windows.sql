-- Generated from validated samples; original trace and matching logcat required.
-- Game pid=1094, tid=1195; explicit REALTIME-BOOTTIME offset=1789885938447045119ns.
-- Per-case JSON timestamps have microsecond-scale precision, not nanosecond.
SELECT name,value FROM stats WHERE severity != 'info' AND value > 0;
SELECT COUNT(*) snapshots, MIN(clock_value-ts) min_offset_ns,
       MAX(clock_value-ts) max_offset_ns,
       MAX(clock_value-ts)-MIN(clock_value-ts) spread_ns
FROM clock_snapshot WHERE clock_name='REALTIME';
SELECT t.utid,t.tid,t.name,p.pid,p.name process FROM thread t JOIN process p USING(upid)
WHERE p.pid=1094 AND t.tid=1195;
CREATE PERFETTO TABLE hitch_windows AS
WITH windows(label,a,b) AS (VALUES ('1_offroad_4x4_shallow05/frame/2',370230504971881,370230542784881),
('1_offroad_4x4_shallow30/frame/359',370236834011881,370236860234881),
('1_offroad_4x4_calm/frame/981',370247528654881,370247545902881),
('1_offroad_4x4_calm/frame/1252',370252045239881,370252065064881),
('1_offroad_4x4_calm/frame/1258',370252147856881,370252164772881),
('1_offroad_4x4_calm/frame/1371',370254032077881,370254047609881),
('1_offroad_4x4_current/frame/1734',370260682389881,370260712754881),
('1_offroad_4x4_current/frame/1998',370265086842881,370265104321881),
('1_offroad_4x4_current/frame/2275',370269703163881,370269718489881),
('1_offroad_4x4_current/frame/2388',370271586569881,370271603256881),
('1_rally_shallow05/frame/2780',370280532991881,370280579195881),
('1_rally_shallow30/frame/3137',370286992922881,370287021978881),
('1_rally_calm/frame/3594',370295087756881,370295107542881),
('1_rally_calm/frame/3669',370296335460881,370296353353881),
('1_rally_calm/frame/3759',370297834859881,370297852731881),
('1_rally_calm/frame/4149',370304335703881,370304352272881),
('1_rally_current/frame/4512',370310992066881,370311031322881),
('1_rally_current/frame/4685',370313877393881,370313893274881),
('1_rally_current/frame/4775',370315375982881,370315393069881),
('1_rally_current/frame/5165',370321876288881,370321892563881),
('1_rally_tuned_shallow05/frame/5557',370331105942881,370331151441881),
('1_rally_tuned_shallow30/frame/6135',370341227936881,370341257688881),
('1_rally_tuned_shallow30/physics/12364',370341242518881,370341254452881),
('1_rally_tuned_calm/frame/6272',370343957396881,370343991811881),
('1_rally_tuned_calm/frame/6447',370346875047881,370346891853881),
('1_rally_tuned_calm/frame/6537',370348376085881,370348391874881),
('1_rally_tuned_calm/frame/6927',370354875307881,370354891809881),
('1_rally_tuned_current/frame/7465',370364448625881,370364466484881),
('1_rally_tuned_current/frame/7555',370365949847881,370365966043881),
('1_rally_tuned_current/frame/7906',370371801022881,370371834823881),
('1_rally_tuned_current/frame/7944',370372431215881,370372447631881),
('1_rally_tuned_current/physics/15798',370370830511881,370370840629881),
('1_rally_tuned_current/physics/15839',370371165265881,370371170333881),
('1_rally_tuned_current/physics/15882',370371528358881,370371535275881),
('1_rally_tuned_current/physics/16244',370374537849881,370374544265881),
('1_rally_tuned_current/physics/16262',370374686836881,370374693726881),
('2_offroad_4x4_shallow05/frame/8335',370381780411881,370381827667881),
('2_offroad_4x4_shallow05/frame/8336',370381827667881,370381880716881),
('2_offroad_4x4_shallow30/frame/8748',370389205468881,370389225488881),
('2_offroad_4x4_calm/frame/9050',370394732743881,370394763065881),
('2_offroad_4x4_calm/frame/9314',370399129124881,370399145917881),
('2_offroad_4x4_calm/frame/9591',370403744693881,370403762112881),
('2_offroad_4x4_calm/frame/9704',370405628084881,370405644929881),
('2_offroad_4x4_current/frame/10332',370416686838881,370416704673881),
('2_offroad_4x4_current/frame/10609',370421301972881,370421319601881),
('2_offroad_4x4_current/frame/10680',370422486102881,370422524705881),
('2_offroad_4x4_current/frame/10721',370423182948881,370423199014881),
('2_offroad_4x4_current/physics/21510',370422508801881,370422519219881),
('2_rally_shallow05/frame/11113',370432266472881,370432318208881),
('2_rally_shallow30/frame/11565',370440322747881,370440342268881),
('2_rally_calm/frame/11828',370445220344881,370445251631881),
('2_rally_calm/frame/12003',370448135478881,370448152793881),
('2_rally_calm/frame/12093',370449635199881,370449652398881),
('2_rally_calm/frame/12483',370456135766881,370456152433881),
('2_rally_current/frame/12846',370462816700881,370462840316881),
('2_rally_current/frame/13021',370465726120881,370465744614881),
('2_rally_current/frame/13111',370467227125881,370467243724881),
('2_rally_current/frame/13501',370473725011881,370473741800881),
('2_rally_tuned_shallow05/frame/13893',370482774301881,370482817603881),
('2_rally_tuned_shallow05/physics/28201',370484538163881,370484543358881),
('2_rally_tuned_shallow30/frame/14250',370489237864881,370489268153881),
('2_rally_tuned_calm/frame/14781',370498571072881,370498588264881),
('2_rally_tuned_calm/frame/14871',370500070868881,370500087521881),
('2_rally_tuned_calm/frame/15261',370506571421881,370506589875881),
('2_rally_tuned_calm/frame/15520',370510887153881,370510906841881),
('2_rally_tuned_current/frame/15624',370513206004881,370513244245881),
('2_rally_tuned_current/frame/15797',370516090692881,370516108067881),
('2_rally_tuned_current/frame/15887',370517590429881,370517606309881),
('2_rally_tuned_current/frame/16277',370524091340881,370524108085881)) SELECT * FROM windows;
WITH clipped AS (
 SELECT w.label,w.a,w.b,s.state,MIN(s.ts+s.dur,w.b)-MAX(s.ts,w.a) span
 FROM hitch_windows w JOIN thread_state s ON s.ts<w.b AND s.ts+s.dur>w.a
 JOIN thread t USING(utid) JOIN process p USING(upid)
 WHERE t.tid=1195 AND p.pid=1094 AND s.dur>0
)
SELECT label,ROUND((MAX(b)-MIN(a))/1e6,6) wall_ms,
 ROUND(SUM(CASE WHEN state='Running' THEN span ELSE 0 END)/1e6,6) running_ms,
 ROUND(SUM(CASE WHEN state IN ('R','R+') THEN span ELSE 0 END)/1e6,6) runnable_ms,
 ROUND(SUM(CASE WHEN state='S' THEN span ELSE 0 END)/1e6,6) sleeping_ms,
 ROUND(SUM(CASE WHEN state NOT IN ('Running','R','R+','S') THEN span ELSE 0 END)/1e6,6) other_ms,
 ROUND(SUM(span)/1e6,6) accounted_ms
FROM clipped GROUP BY label ORDER BY label;
-- Missing rows or nonzero coverage error invalidate those intervals.
SELECT w.label,(w.b-w.a)-COALESCE(SUM(MIN(s.ts+s.dur,w.b)-MAX(s.ts,w.a)),0) uncovered_ns
FROM hitch_windows w LEFT JOIN thread_state s
 ON s.ts<w.b AND s.ts+s.dur>w.a AND s.dur>0 AND s.utid IN (
  SELECT t.utid FROM thread t JOIN process p USING(upid) WHERE t.tid=1195 AND p.pid=1094)
GROUP BY w.label,w.a,w.b
HAVING ABS(uncovered_ns)>0;


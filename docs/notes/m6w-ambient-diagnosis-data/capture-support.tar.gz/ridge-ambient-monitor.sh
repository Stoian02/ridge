#!/system/bin/sh
# Read-only, bounded observation of this game's render thread and CPU frequency.
sleep 4
wave_pid=$(pidof com.ridge.game)
if [ -z "$wave_pid" ]; then exit 1; fi
wave_tid=""
for wave_dir in /proc/"$wave_pid"/task/*; do
  wave_name=$(cat "$wave_dir/comm" 2>/dev/null)
  echo "thread ${wave_dir##*/} $wave_name"
  case "$wave_name" in
    GLThread*|GodotRender*) wave_tid=${wave_dir##*/};;
    com.ridge.game) if [ "${wave_dir##*/}" != "$wave_pid" ]; then wave_tid=${wave_dir##*/}; fi;;
  esac
done
echo "observed_pid=$wave_pid observed_tid=$wave_tid"
if [ -z "$wave_tid" ]; then exit 2; fi
echo 'epoch_seconds,uptime_seconds,tid,last_cpu,state,cpu_khz'
wave_i=0
while [ "$wave_i" -lt 95 ] && [ -f /proc/"$wave_pid"/task/"$wave_tid"/stat ]; do
  wave_stat=$(cat /proc/"$wave_pid"/task/"$wave_tid"/stat)
  wave_cpu=$(echo "$wave_stat" | awk '{sub(/^.*\) /, ""); split($0,a," "); print a[37]}')
  wave_state=$(echo "$wave_stat" | awk '{sub(/^.*\) /, ""); split($0,a," "); print a[1]}')
  wave_frequency=$(cat /sys/devices/system/cpu/cpu"$wave_cpu"/cpufreq/scaling_cur_freq)
  wave_uptime=$(cut -d ' ' -f 1 /proc/uptime)
  echo "$(date +%s),$wave_uptime,$wave_tid,$wave_cpu,$wave_state,$wave_frequency"
  wave_i=$((wave_i+1))
  sleep 0.5
done

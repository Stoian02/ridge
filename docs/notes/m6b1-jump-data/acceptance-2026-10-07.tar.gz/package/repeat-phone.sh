#!/usr/bin/env bash
set -euo pipefail
cd /home/stoyan/Projects/claude-projects/ridge
out=runs/m6b1-acceptance-2026-10-07.ZTejbD/phone-r2
mkdir -p "$out"
if adb shell pidof com.ridge.game; then
  echo 'Ridge is already running; refusing to interrupt the owner.'
  exit 2
fi
adb shell run-as com.ridge.game sha256sum files/save.json > "$out/save-before.sha256"
adb exec-out run-as com.ridge.game cat files/save.json > /tmp/ridge-coastal-phone-save-backup.json
git rev-parse HEAD > "$out/source-commit.txt"
sha256sum build/ridge-debug.apk > "$out/apk.sha256"
adb install -r build/ridge-debug.apk
adb shell pm path com.ridge.game > "$out/installed-path.txt"
for mode in loads views drive soak; do
  mkdir -p "$out/$mode"
  adb shell dumpsys battery > "$out/$mode/battery-before.txt"
  adb shell dumpsys thermalservice > "$out/$mode/thermal-before.txt"
  printf '{"mode":"%s","tc":0.2}\n' "$mode" > /tmp/ridge-coastal-acceptance-options.json
  adb push /tmp/ridge-coastal-acceptance-options.json /data/local/tmp/ridge-coastal-acceptance-options.json >/dev/null
  adb shell run-as com.ridge.game cp /data/local/tmp/ridge-coastal-acceptance-options.json files/coastal_acceptance
  tools/android.sh run
  sleep 2
  test_pid=$(adb shell pidof com.ridge.game | tr -d '\r')
  if [[ -z "$test_pid" ]]; then
    echo 'App did not start; stopping rather than counting stale results.'
    exit 3
  fi
  echo "PHONE_START $mode"
  elapsed=0
  while adb shell pidof com.ridge.game >/dev/null; do
    sleep 2
    elapsed=$((elapsed + 2))
    if (( elapsed % 30 == 0 )); then
      echo "PHONE_PROGRESS $mode ${elapsed}s"
      app_pid=$(adb shell pidof com.ridge.game | tr -d '\r')
      if [[ -n "$app_pid" ]]; then
        adb logcat -d --pid="$app_pid" -v threadtime -s godot > "$out/$mode/live-logcat.txt"
        if rg -q 'SCRIPT ERROR|ERROR:' "$out/$mode/live-logcat.txt"; then
          echo 'Script/engine error in this measurement process; retaining log and stopping the test.'
          adb shell am force-stop com.ridge.game
          exit 5
        fi
      fi
    fi
    if (( elapsed > 1500 )); then
      echo 'Timed out; leaving app untouched for investigation.'
      exit 4
    fi
  done
  adb exec-out run-as com.ridge.game tar cf - files/coastal_acceptance_results > "$out/$mode/results.tar"
  adb logcat -d --pid="$test_pid" -v threadtime -s godot > "$out/$mode/logcat.txt"
  if rg -q 'SCRIPT ERROR|ERROR:' "$out/$mode/logcat.txt"; then
    echo 'Script/engine error: this case is not accepted.'
    exit 6
  fi
  adb shell dumpsys battery > "$out/$mode/battery-after.txt"
  adb shell dumpsys thermalservice > "$out/$mode/thermal-after.txt"
  adb exec-out run-as com.ridge.game cat files/coastal_acceptance_results/complete.json | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d); assert d["mode"] == sys.argv[1] and not d["functional_failure"]' "$mode"
  echo "PHONE_DONE $mode"
done
adb shell run-as com.ridge.game sha256sum files/save.json > "$out/save-after.sha256"
cmp "$out/save-before.sha256" "$out/save-after.sha256"
adb shell run-as com.ridge.game ls files > "$out/files-after.txt"
echo 'PHONE_COMPLETE save unchanged'

"""Independently recompute Coastal frame JSON from the retained phone CSVs."""
import csv
import io
import json
import math
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).parent / (sys.argv[1] if len(sys.argv) > 1 else "phone-r2")


def percentile(values, fraction):
    return sorted(values)[max(0, math.ceil(len(values) * fraction) - 1)]


for mode in ("loads", "views", "drive", "soak"):
    archive = ROOT / mode / "results.tar"
    if not archive.exists():
        print(mode, "PENDING")
        continue
    with tarfile.open(archive) as tar:
        data = {Path(m.name).name: tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
    complete = json.loads(data["complete.json"])
    assert complete["mode"] == mode, (mode, "stale completion")
    assert not complete["functional_failure"], (mode, "functional failure")
    metadata = json.loads(data["metadata.json"])
    print("MODE", mode, "device", metadata["processor"], "window", metadata["window"])
    if mode == "loads":
        for i in range(4):
            d = json.loads(data[f"load_{i}_load.json"])
            assert d["water_bodies"] == d["wave_bindings"] == 0
            print("LOAD", i, {k: d[k] for k in ("resource_ms", "instantiate_ms", "ready_ms", "resource_through_ready_ms", "trail_seconds", "harness_cover_ms", "first_interactive_from_cover_ms")})
        continue
    for name in sorted(data):
        prefix = {"views": "view_", "drive": "drive_", "soak": "soak"}[mode]
        if not name.startswith(prefix) or not name.endswith("_frames.csv"):
            continue
        rows = list(csv.DictReader(io.StringIO(data[name].decode())))
        values = [float(r["frame_usec"]) / 1000 for r in rows]
        water = [float(r["water_upper_usec"]) / 1000 for r in rows]
        record = json.loads(data[name.replace("_frames.csv", ".json")])
        if mode == "drive":
            route = record["route"]
            assert route["reached"] and route["upright"] and route["resets"] == 0
            assert route["gates"] == list(range(1, route["expected_last_gate"]))
            assert route["last_gate"] == route["expected_last_gate"]
            print("ROUTE", route["car"], route["seconds"], "seconds", route["max_lane_fraction"], "lane fraction")
            record = record["frames"]
        result = {
            "frames": len(rows), "seconds": sum(values) / 1000,
            "fps": 1000 * len(values) / sum(values),
            "p95_ms": percentile(values, .95), "p99_ms": percentile(values, .99),
            "max_ms": max(values), "empty_water_upper_p95_ms": percentile(water, .95),
            "empty_water_upper_p99_ms": percentile(water, .99),
            "draw_peak": max(int(float(r["draws"])) for r in rows),
            "primitive_peak": max(int(float(r["primitives"])) for r in rows),
        }
        for key, value in result.items():
            assert math.isclose(value, record[key], rel_tol=1e-6, abs_tol=1e-6), (name, key, value, record[key])
        tails = [r for r in rows if float(r["frame_usec"]) > 33300]
        assert len(tails) == len(record["tails"])
        result["tails_start"] = sum(float(r["case_elapsed_usec"]) - float(r["frame_usec"]) <= 100000 for r in tails)
        result["tails_warmed"] = len(tails) - result["tails_start"]
        result["budget_pass"] = (result["fps"] >= 59 and result["p95_ms"] <= 18.5
                                 and result["p99_ms"] <= 25 and result["draw_peak"] < 150
                                 and result["primitive_peak"] < 300000)
        print(name, json.dumps(result, sort_keys=True))
        for tail in record["tails"]:
            print("TAIL", name, json.dumps(tail, sort_keys=True))
print("All available CSV/JSON values agree; pending modes above are not passes.")

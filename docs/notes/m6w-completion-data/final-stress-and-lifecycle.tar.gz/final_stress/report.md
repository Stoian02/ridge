
## final_stress: {'car': 'offroad_4x4', 'fixture': 'stress', 'modes': '0,2,3', 'rounds': 3.0, 'seconds': 30.0, 'settle_seconds': 10.0, 'tag': 'final_stress', 'warm_seconds': 60.0}

CPU policy: Test Ground 6/7 ms p95/p99. Modes: 0 Off, 1 Car waves, 2 Full, 3 debug refined-flat.

Feedback scope: water regions incl. shared wet spray/mixed tyre audio; whole mixed upper bound retained separately 

| Case | Water p95/p99 ms | CPU | Frame p95/p99 ms | FPS | Frame | Max ms / tails | GPU p95 | Draws / primitives max | Setup ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| offroad_4x4_r0_o0_m0 | 2.726/2.918 | PASS | 17.128/18.262 | 60.003 | PASS | 22.706 / 0 | 8.660 | 84 / 269315 | 42.790 |
| offroad_4x4_r0_o1_m2 | 6.990/7.184 | FAIL | 17.057/17.884 | 60.018 | PASS | 21.745 / 0 | 9.569 | 84 / 293409 | 42.790 |
| offroad_4x4_r0_o2_m3 | 4.824/5.002 | PASS | 17.313/18.418 | 60.023 | PASS | 20.376 / 0 | 9.483 | 87 / 293553 | 42.790 |
| offroad_4x4_r1_o0_m2 | 7.039/7.179 | FAIL | 17.193/18.312 | 60.016 | PASS | 21.607 / 0 | 9.587 | 84 / 293409 | 42.790 |
| offroad_4x4_r1_o1_m3 | 4.807/5.002 | PASS | 17.540/19.040 | 59.986 | PASS | 53.558 / 1 | 9.476 | 87 / 293553 | 42.790 |
| offroad_4x4_r1_o2_m0 | 2.737/2.958 | PASS | 17.161/17.884 | 60.030 | PASS | 19.671 / 0 | 8.668 | 84 / 269315 | 42.790 |
| offroad_4x4_r2_o0_m3 | 3.588/3.782 | PASS | 17.106/17.581 | 60.021 | PASS | 19.306 / 0 | 9.442 | 87 / 293553 | 42.790 |
| offroad_4x4_r2_o1_m0 | 2.709/2.872 | PASS | 17.205/17.876 | 60.016 | PASS | 20.514 / 0 | 8.695 | 84 / 269315 | 42.790 |
| offroad_4x4_r2_o2_m2 | 6.995/7.208 | FAIL | 17.258/18.572 | 60.020 | PASS | 20.549 / 0 | 9.619 | 84 / 293409 | 42.790 |

Matched-case GPU p95 differences versus Off (unchanged +0.50 ms allocation):
- offroad_4x4 round 0 mode 2: +0.909 ms (outside/unavailable); valid=True
- offroad_4x4 round 0 mode 3: +0.823 ms (outside/unavailable); valid=True
- offroad_4x4 round 1 mode 2: +0.919 ms (outside/unavailable); valid=True
- offroad_4x4 round 1 mode 3: +0.808 ms (outside/unavailable); valid=True
- offroad_4x4 round 2 mode 2: +0.924 ms (outside/unavailable); valid=True
- offroad_4x4 round 2 mode 3: +0.747 ms (outside/unavailable); valid=True

Retained >33.3 ms frame/tick records (correlation only, not cause):
[
  {
    "case": "offroad_4x4_r1_o1_m3",
    "frame": {
      "process_frame": 15081.0,
      "frame_usec": 53558.0,
      "physics_ticks": 2.0,
      "controller_usec": 17385.0,
      "runtime_usec": 20277.0,
      "emitter_usec": 0.0,
      "coordinator_usec": 10.0,
      "effects_upper_usec": 166.0,
      "audio_upper_usec": 22.0,
      "hud_usec": 23.0,
      "flat_usec": 0.0,
      "total_upper_usec": 37883.0,
      "wave_query_usec": 599.0,
      "gpu_ms": 9.29399967193604,
      "render_cpu_ms": 0.55199998617172,
      "draws": 87.0,
      "primitives": 293553.0,
      "effects_all_usec": 191.0,
      "audio_all_usec": 103.0,
      "total_mixed_upper_usec": 37989.0,
      "end_usec": 256553431.0
    },
    "ticks": [
      {
        "process_frame": 15081.0,
        "physics_tick": 30194.0,
        "controller_usec": 16959.0,
        "runtime_usec": 20061.0,
        "emitter_usec": 0.0,
        "coordinator_usec": 6.0,
        "wave_query_usec": 453.0,
        "immersion": 0.9056925969032,
        "flooding": 1.0,
        "stalled": 0.0,
        "vertices": 19.0,
        "packets": 0.0,
        "x": 105.0,
        "y": 2.5,
        "z": 126.0,
        "velocity_x": 0.0,
        "velocity_y": 0.0,
        "velocity_z": 3.0
      },
      {
        "process_frame": 15081.0,
        "physics_tick": 30195.0,
        "controller_usec": 426.0,
        "runtime_usec": 216.0,
        "emitter_usec": 0.0,
        "coordinator_usec": 4.0,
        "wave_query_usec": 146.0,
        "immersion": 0.9056925969032,
        "flooding": 1.0,
        "stalled": 0.0,
        "vertices": 19.0,
        "packets": 0.0,
        "x": 105.0,
        "y": 2.5,
        "z": 126.0,
        "velocity_x": 0.0,
        "velocity_y": 0.0,
        "velocity_z": 3.0
      }
    ],
    "clock_anchor": {
      "after_usec": 235698984,
      "before_usec": 235698979,
      "unix": 1790339559.92732
    }
  }
]

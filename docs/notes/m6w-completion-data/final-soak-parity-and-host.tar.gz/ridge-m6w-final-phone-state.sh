#!/usr/bin/env bash
set -euo pipefail
cd /home/stoyan/Projects/claude-projects/ridge
out=/tmp/ridge-m6w-completion-data/final-batch-host
if adb shell pidof com.ridge.game >/dev/null; then
  echo 'Game is running; leaving it and the phone trace untouched.'
  exit 1
fi
adb devices -l > "$out/final-device.txt"
adb shell 'getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk' >> "$out/final-device.txt"
adb shell 'p=$(pm path com.ridge.game); sha256sum "${p#package:}"' > "$out/final-installed-apk-sha256.txt"
adb shell run-as com.ridge.game sha256sum files/save.json > "$out/final-save-sha256.txt"
adb shell run-as com.ridge.game ls files > "$out/final-files.txt"
cmp /tmp/ridge-m6w-completion-data/final_matrix/save-before.txt "$out/final-save-sha256.txt"
adb shell sha256sum /data/misc/perfetto-traces/ridge-m6w-final-soak.pftrace > "$out/phone-trace-sha256.txt"
read -r phone_trace_hash unused_path < "$out/phone-trace-sha256.txt"
read -r local_trace_hash unused_path < <(sha256sum /tmp/ridge-m6w-final-soak.pftrace)
test "$phone_trace_hash" = "$local_trace_hash"
gzip -t runs/m6w-completion-data/final-soak.pftrace.gz
# Only this run's exported temporary system trace is removed. Local raw and
# verified gzip remain recoverable; no app/save/results/cache files are removed.
adb shell rm /data/misc/perfetto-traces/ridge-m6w-final-soak.pftrace
echo 'Removed only the verified exported phone system trace; local raw/gzip retained.'

-- All >33.3 ms intervals, no threshold-based omissions. Brackets are microseconds.
-- Also includes each case maximum even below 33.3 ms; these are not mislabeled hitches.
SELECT name,value FROM stats WHERE severity != 'info' AND value > 0;
SELECT COUNT(*) snapshots, MAX(clock_value-ts)-MIN(clock_value-ts) offset_spread_ns FROM clock_snapshot WHERE clock_name='REALTIME';
SELECT t.utid,t.tid,t.name,p.pid,p.name process FROM thread t JOIN process p USING(upid) WHERE p.name='com.ridge.game' AND t.name='VkThread';
CREATE PERFETTO TABLE wave_windows AS
WITH raw(label,frame,a_unix,b_unix,bracket_us) AS (VALUES
('offroad_4x4_r0_o0_m2',4832,1790341172263343000,1790341172288957000,2),
('rally_r0_o0_m2',34156,1790341665365864500,1790341665387184500,5),
('rally_tuned_r0_o0_m2',53799,1790341996488849500,1790341996519965500,5)),
nearest AS (SELECT raw.*,c.clock_value-c.ts offset_ns,ROW_NUMBER() OVER (PARTITION BY label,frame ORDER BY ABS(c.clock_value-b_unix)) n FROM raw CROSS JOIN clock_snapshot c WHERE c.clock_name='REALTIME')
SELECT label,frame,a_unix-offset_ns a,b_unix-offset_ns b,bracket_us FROM nearest WHERE n=1;
SELECT label,frame,bracket_us,ROUND((b-a)/1e6,3) interval_ms FROM wave_windows;
SELECT label,frame,s.state,ROUND(SUM(MIN(s.ts+s.dur,b)-MAX(s.ts,a))/1e6,3) ms,COUNT(*) spans FROM wave_windows JOIN thread_state s ON s.ts<b AND s.ts+s.dur>a JOIN thread t USING(utid) JOIN process p USING(upid) WHERE p.name='com.ridge.game' AND t.name='VkThread' GROUP BY label,frame,s.state ORDER BY label,frame,ms DESC;

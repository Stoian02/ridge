#!/usr/bin/env bash
set -euo pipefail
cd /home/stoyan/Projects/claude-projects/ridge
action=${1:?start or fetch}
out=/tmp/ridge-m6w-completion-data/final_parity
mkdir -p "$out"
if [[ "$action" == start ]]; then
  if adb shell pidof com.ridge.game >/dev/null; then
    echo 'Game already running; refusing to interrupt it.'
    exit 1
  fi
  git rev-parse HEAD > "$out/revision.txt"
  git diff --binary > "$out/working-tree.patch"
  sha256sum build/ridge-debug.apk > "$out/apk-sha256.txt"
  adb shell run-as com.ridge.game sha256sum files/save.json > "$out/save-before.txt"
  adb shell 'p=$(pm path com.ridge.game); sha256sum "${p#package:}"' > "$out/installed-apk-sha256.txt"
  printf '%s' '{"mode":"wave_lab"}' | adb shell run-as com.ridge.game sh -c '"cat > files/water_acceptance"'
  tools/android.sh run > "$out/launch.txt" 2>&1
elif [[ "$action" == fetch ]]; then
  if adb shell pidof com.ridge.game >/dev/null; then
    echo 'Parity is still running.'
    exit 1
  fi
  adb logcat -d -v threadtime -s godot:V > "$out/logcat.txt"
  adb shell run-as com.ridge.game sha256sum files/save.json > "$out/save-after.txt"
  adb shell run-as com.ridge.game ls files > "$out/files-after.txt"
  cmp "$out/save-before.txt" "$out/save-after.txt"
  rg 'wave GPU|wave lab preparation' "$out/logcat.txt"
else
  exit 2
fi

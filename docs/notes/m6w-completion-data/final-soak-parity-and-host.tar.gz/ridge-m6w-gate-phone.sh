#!/usr/bin/env bash
set -euo pipefail
cd /home/stoyan/Projects/claude-projects/ridge
action=${1:?start, fetch or status}
tag=${2:?tag}
case "$tag" in *[!a-zA-Z0-9_-]*|'') exit 2;; esac
out=/tmp/ridge-m6w-completion-data/$tag
mkdir -p "$out"
if [[ "$action" == start ]]; then
  config=${3:?JSON config}
  if adb shell pidof com.ridge.game >/dev/null; then
    echo 'Game is already running; refusing to interrupt it.'
    exit 1
  fi
  git rev-parse HEAD > "$out/revision.txt"
  git diff --binary > "$out/working-tree.patch"
  sha256sum build/ridge-debug.apk > "$out/apk-sha256.txt"
  adb shell run-as com.ridge.game sha256sum files/save.json > "$out/save-before.txt"
  tools/android.sh install > "$out/install.txt" 2>&1
  adb shell 'p=$(pm path com.ridge.game); sha256sum "${p#package:}"' > "$out/installed-apk-sha256.txt"
  adb shell dumpsys battery > "$out/battery-before.txt"
  adb shell dumpsys thermalservice > "$out/thermal-before.txt"
  printf '%s' "$config" | adb shell run-as com.ridge.game sh -c '"cat > files/wave_acceptance"'
  tools/android.sh run > "$out/launch.txt" 2>&1
  echo "Started $tag; evidence destination $out"
elif [[ "$action" == status ]]; then
  adb shell run-as com.ridge.game cat "files/wave_acceptance_results/$tag/summary.json" | python3 -c 'import json,sys; rows=json.load(sys.stdin); print("Completed cases:",len(rows)); [print(r["case"],"water",r["total_upper_p95_ms"],r["total_upper_p99_ms"],"frame",r["frame_p95_ms"],r["frame_p99_ms"],"fps",round(r["fps"],2),"tails",r["over_33ms"]) for r in rows]'
elif [[ "$action" == fetch ]]; then
  if adb shell pidof com.ridge.game >/dev/null; then
    echo 'Measurement is still running.'
    exit 1
  fi
  adb shell -T run-as com.ridge.game tar -C files -cf - "wave_acceptance_results/$tag" > "$out/results.tar"
  tar -xf "$out/results.tar" -C "$out"
  adb logcat -d -v threadtime -s godot:V > "$out/logcat.txt"
  adb shell run-as com.ridge.game sha256sum files/save.json > "$out/save-after.txt"
  adb shell dumpsys battery > "$out/battery-after.txt"
  adb shell dumpsys thermalservice > "$out/thermal-after.txt"
  adb shell run-as com.ridge.game ls files > "$out/files-after.txt"
  cmp "$out/save-before.txt" "$out/save-after.txt"
  if [[ -f "$out/wave_acceptance_results/$tag/lifecycle.json" ]]; then
    python3 -c 'import json,sys; r=json.load(open(sys.argv[1])); print("Lifecycle",r["passed"],"checks",len(r["checks"]),"rounds",len(r["rounds"])); sys.exit(0 if r["passed"] else 1)' "$out/wave_acceptance_results/$tag/lifecycle.json" | tee "$out/validation.txt"
  else
    python3 -B tools/check_wave_acceptance.py "$out/wave_acceptance_results/$tag" | tee "$out/validation.txt"
  fi
else
  exit 2
fi

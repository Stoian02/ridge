#!/usr/bin/env bash
# Opt-in idle-device final checks; source/build must be pinned before starting.
set -euo pipefail
cd /home/stoyan/Projects/claude-projects/ridge
batch=/tmp/ridge-m6w-completion-data/final-batch-host
mkdir -p "$batch"
if adb shell pidof com.ridge.game >/dev/null; then
  echo 'Game already running; refusing to interrupt it.'
  exit 1
fi
adb logcat -v threadtime -s godot:V > "$batch/phone-stream.log" 2>&1 &
logcat_pid=$!
trap 'kill "$logcat_pid" 2>/dev/null || true' EXIT
run_case() {
  local tag=$1
  local config=$2
  bash /tmp/ridge-m6w-gate-phone.sh start "$tag" "$config"
  # Android's launcher can return before the application process exists.
  sleep 5
  bash /tmp/ridge-m6w-phone-monitor.sh > "$batch/$tag-thermal.log" 2>&1 &
  local monitor_pid=$!
  while adb shell pidof com.ridge.game >/dev/null; do
    sleep 10
  done
  wait "$monitor_pid"
  bash /tmp/ridge-m6w-gate-phone.sh fetch "$tag"
  if [[ "$tag" != final_lifecycle* ]]; then
    python3 -B tools/report_wave_acceptance.py "/tmp/ridge-m6w-completion-data/$tag/wave_acceptance_results/$tag" > "/tmp/ridge-m6w-completion-data/$tag/report.md"
  fi
  printf 'FINISHED %s\n' "$tag"
}
run_case final_lifecycle_repeat '{"tag":"final_lifecycle_repeat","fixture":"lifecycle","rounds":3}'
run_case final_stress '{"tag":"final_stress","fixture":"stress","warm_seconds":60,"settle_seconds":10,"seconds":30,"rounds":3,"car":"offroad_4x4","modes":"0,2,3"}'
run_case final_live '{"tag":"final_live","fixture":"live","warm_seconds":60,"settle_seconds":10,"seconds":108,"rounds":1,"car":"all","modes":"0,1,2"}'
adb shell perfetto --txt -c - -o /data/misc/perfetto-traces/ridge-m6w-final-soak.pftrace < /tmp/ridge-m6w-final-trace.pbtxt > "$batch/perfetto.log" 2>&1 &
trace_pid=$!
sleep 3
run_case final_soak '{"tag":"final_soak","fixture":"live","warm_seconds":60,"settle_seconds":10,"seconds":300,"rounds":1,"car":"all","modes":"2"}'
wait "$trace_pid"
adb pull /data/misc/perfetto-traces/ridge-m6w-final-soak.pftrace /tmp/ridge-m6w-final-soak.pftrace > "$batch/trace-pull.log" 2>&1
bash /tmp/ridge-m6w-phone-parity.sh start
sleep 5
while adb shell pidof com.ridge.game >/dev/null; do
  sleep 5
done
bash /tmp/ridge-m6w-phone-parity.sh fetch
printf 'FINAL PHONE BATCH FINISHED\n'


## final_soak: {'car': 'all', 'fixture': 'live', 'modes': '2', 'rounds': 1.0, 'seconds': 300.0, 'settle_seconds': 10.0, 'tag': 'final_soak', 'warm_seconds': 60.0}

CPU policy: Test Ground 6/7 ms p95/p99. Modes: 0 Off, 1 Car waves, 2 Full, 3 debug refined-flat.

Feedback scope: water regions incl. shared wet spray/mixed tyre audio; whole mixed upper bound retained separately 

| Case | Water p95/p99 ms | CPU | Frame p95/p99 ms | FPS | Frame | Max ms / tails | GPU p95 | Draws / primitives max | Setup ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| offroad_4x4_r0_o0_m2 | 4.882/5.101 | PASS | 17.474/18.339 | 60.002 | PASS | 25.614 / 0 | 9.217 | 82 / 239837 | 53.940 |
| rally_r0_o0_m2 | 4.869/5.072 | PASS | 17.480/18.335 | 60.007 | PASS | 21.320 / 0 | 8.789 | 82 / 239381 | 45.597 |
| rally_tuned_r0_o0_m2 | 4.888/5.105 | PASS | 17.507/18.355 | 60.007 | PASS | 31.116 / 0 | 9.354 | 82 / 239453 | 40.497 |

Matched-case GPU p95 differences versus Off (unchanged +0.50 ms allocation):
LIVE trajectories differ: these differences are descriptive, NOT matched-pose GPU acceptance.

Retained >33.3 ms frame/tick records (correlation only, not cause):
[]

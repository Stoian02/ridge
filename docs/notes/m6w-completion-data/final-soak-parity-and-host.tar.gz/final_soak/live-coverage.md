# Live fixture coverage (initial speeds in m/s; ordinary forces thereafter)

Nominal phase classification excludes 0.1 s around each reset boundary.
Exit deliberately initializes a stalled state; other stalls below are naturally earned.
These are scripted trajectories, not owner feel acceptance or matched GPU views.

| Case / segment | Ticks | Immersion min–max | Flood max | Stalled ticks/end | Max packets | xyz excursion m | Water p95 ms |
| --- | --- | --- | --- | --- | --- | --- | --- |
| offroad_4x4_r0_o0_m2 / entry_initial_3 | 4472 | 0.000–1.000 | 0.822 | 0/0 | 11 | 0.034 / 1.788 / 29.816 | 5.016 |
| offroad_4x4_r0_o0_m2 / entry_initial_8 | 5439 | 0.000–1.000 | 0.878 | 0/0 | 10 | 0.494 / 1.816 / 29.822 | 4.878 |
| offroad_4x4_r0_o0_m2 / entry_initial_15 | 4248 | 0.000–1.000 | 0.936 | 0/0 | 10 | 0.602 / 1.863 / 29.999 | 4.883 |
| offroad_4x4_r0_o0_m2 / reverse_initial_8 | 4248 | 0.000–0.956 | 0.636 | 0/0 | 10 | 0.015 / 1.334 / 20.831 | 5.079 |
| offroad_4x4_r0_o0_m2 / current_deep | 4248 | 0.834–1.000 | 1.000 | 1026/1 | 0 | 1.574 / 1.905 / 0.034 | 3.981 |
| offroad_4x4_r0_o0_m2 / calm_deep | 4248 | 0.832–1.000 | 1.000 | 1026/1 | 0 | 0.003 / 1.910 / 0.029 | 4.008 |
| offroad_4x4_r0_o0_m2 / initialized_stall_exit | 4248 | 0.000–0.432 | 0.000 | 327/0 | 7 | 0.028 / 3.046 / 133.605 | 4.468 |
| offroad_4x4_r0_o0_m2 / shallow | 4248 | 0.000–0.193 | 0.000 | 0/0 | 9 | 0.021 / 0.555 / 125.562 | 4.480 |
| rally_r0_o0_m2 / entry_initial_3 | 4473 | 0.000–1.000 | 0.867 | 2808/1 | 10 | 0.164 / 1.818 / 26.722 | 4.908 |
| rally_r0_o0_m2 / entry_initial_8 | 5437 | 0.000–1.000 | 0.919 | 3409/1 | 10 | 0.053 / 1.851 / 26.858 | 4.975 |
| rally_r0_o0_m2 / entry_initial_15 | 4248 | 0.000–1.000 | 0.972 | 2838/1 | 9 | 0.125 / 1.934 / 27.801 | 4.939 |
| rally_r0_o0_m2 / reverse_initial_8 | 4248 | 0.000–1.000 | 0.799 | 2010/1 | 9 | 0.015 / 1.444 / 19.090 | 4.984 |
| rally_r0_o0_m2 / current_deep | 4248 | 0.743–1.000 | 1.000 | 3201/1 | 0 | 1.769 / 2.170 / 0.034 | 3.890 |
| rally_r0_o0_m2 / calm_deep | 4248 | 0.743–1.000 | 1.000 | 3201/1 | 0 | 0.007 / 2.174 / 0.025 | 3.937 |
| rally_r0_o0_m2 / initialized_stall_exit | 4248 | 0.000–0.659 | 0.000 | 474/0 | 8 | 0.128 / 3.045 / 138.774 | 4.513 |
| rally_r0_o0_m2 / shallow | 4248 | 0.000–0.392 | 0.000 | 0/0 | 9 | 0.018 / 0.539 / 121.288 | 4.505 |
| rally_tuned_r0_o0_m2 / entry_initial_3 | 4473 | 0.000–1.000 | 0.878 | 2835/1 | 10 | 0.132 / 1.803 / 26.672 | 4.963 |
| rally_tuned_r0_o0_m2 / entry_initial_8 | 5437 | 0.000–1.000 | 0.925 | 3405/1 | 9 | 0.087 / 1.830 / 26.712 | 4.976 |
| rally_tuned_r0_o0_m2 / entry_initial_15 | 4248 | 0.000–1.000 | 0.976 | 2853/1 | 9 | 0.173 / 1.899 / 27.403 | 4.967 |
| rally_tuned_r0_o0_m2 / reverse_initial_8 | 4248 | 0.000–1.000 | 0.800 | 2010/1 | 9 | 0.017 / 1.423 / 18.897 | 5.034 |
| rally_tuned_r0_o0_m2 / current_deep | 4248 | 0.743–1.000 | 1.000 | 3201/1 | 0 | 1.819 / 2.146 / 0.036 | 3.928 |
| rally_tuned_r0_o0_m2 / calm_deep | 4248 | 0.743–1.000 | 1.000 | 3201/1 | 0 | 0.008 / 2.149 / 0.026 | 4.022 |
| rally_tuned_r0_o0_m2 / initialized_stall_exit | 4248 | 0.000–0.608 | 0.000 | 327/0 | 7 | 0.162 / 3.035 / 159.528 | 4.534 |
| rally_tuned_r0_o0_m2 / shallow | 4248 | 0.000–0.342 | 0.000 | 0/0 | 9 | 0.028 / 0.653 / 129.571 | 4.481 |

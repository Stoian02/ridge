#!/usr/bin/env bash
set -euo pipefail
for wave_poll in $(seq 1 150); do
  if ! adb -s 41374bac shell pidof com.ridge.game >/dev/null; then exit 0; fi
  date -u '+%Y-%m-%dT%H:%M:%SZ'
  adb -s 41374bac shell dumpsys battery | rg 'powered:|level:|temperature:'
  adb -s 41374bac shell dumpsys thermalservice | rg 'Thermal Status:'
  adb -s 41374bac shell 'for wave_cpu in 0 4 7; do printf "cpu%s " "$wave_cpu"; cat /sys/devices/system/cpu/cpu${wave_cpu}/cpufreq/scaling_cur_freq; done'
  sleep 30
done

#!/usr/bin/env python3
"""Emit reproducible Perfetto SQL for every retained v3 long-frame interval.

Usage: python3 ridge-m6w-trace-windows.py <run> --tid <game-thread TID> [--include-max] > windows.sql
Then trace_processor query -f windows.sql <matching trace>. Never use it to
attribute an untraced earlier run. Clock alignment uses each case's bracketed
UNIX/uptime pair; SQL picks the nearest captured REALTIME offset for each frame.
"""
import argparse
import csv
import json
import sys
from decimal import Decimal
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("directory", type=Path)
parser.add_argument("--include-max", action="store_true")
parser.add_argument("--tid", type=int, required=True,
                    help="Game thread from contemporaneous logcat; several Vulkan workers may share its name")
args = parser.parse_args()
directory = args.directory
include_max = args.include_max
results = json.loads((directory / "summary.json").read_text(), parse_float=Decimal)
windows = []
for result in results:
    clock = result["clock_anchor"]
    uptime = (clock["before_usec"] + clock["after_usec"]) / Decimal(2)
    width = clock["after_usec"] - clock["before_usec"]
    with (directory / (result["case"] + "_frames.csv")).open() as stream:
        frames = list(csv.DictReader(stream))
        longest = max(frames, key=lambda row: Decimal(row["frame_usec"]))
        for row in frames:
            duration = Decimal(row["frame_usec"])
            if duration <= 33300 and not (include_max and row is longest):
                continue
            end = clock["unix"] * 1000000000 + (Decimal(row["end_usec"]) - uptime) * 1000
            begin = end - duration * 1000
            label = result["case"].replace("'", "''")
            windows.append(f"('{label}',{int(float(row['process_frame']))},{int(begin)},{int(end)},{width})")
print("-- All >33.3 ms intervals, no threshold-based omissions. Brackets are microseconds.")
if include_max:
    print("-- Also includes each case maximum even below 33.3 ms; these are not mislabeled hitches.")
print("SELECT name,value FROM stats WHERE severity != 'info' AND value > 0;")
print("SELECT COUNT(*) snapshots, MAX(clock_value-ts)-MIN(clock_value-ts) offset_spread_ns FROM clock_snapshot WHERE clock_name='REALTIME';")
print("SELECT t.utid,t.tid,t.name,p.pid,p.name process FROM thread t JOIN process p USING(upid) WHERE p.name='com.ridge.game' AND t.name='VkThread';")
if not windows:
    print("-- No long frames in this run; no hitch-attribution query is generated.")
    raise SystemExit(0)
print("CREATE PERFETTO TABLE wave_windows AS")
print("WITH raw(label,frame,a_unix,b_unix,bracket_us) AS (VALUES\n" + ",\n".join(windows) + "),")
print("nearest AS (SELECT raw.*,c.clock_value-c.ts offset_ns,ROW_NUMBER() OVER (PARTITION BY label,frame ORDER BY ABS(c.clock_value-b_unix)) n FROM raw CROSS JOIN clock_snapshot c WHERE c.clock_name='REALTIME')")
print("SELECT label,frame,a_unix-offset_ns a,b_unix-offset_ns b,bracket_us FROM nearest WHERE n=1;")
print("SELECT label,frame,bracket_us,ROUND((b-a)/1e6,3) interval_ms FROM wave_windows;")
print(f"SELECT label,frame,s.state,ROUND(SUM(MIN(s.ts+s.dur,b)-MAX(s.ts,a))/1e6,3) ms,COUNT(*) spans FROM wave_windows JOIN thread_state s ON s.ts<b AND s.ts+s.dur>a JOIN thread t USING(utid) JOIN process p USING(upid) WHERE p.name='com.ridge.game' AND t.tid={args.tid} GROUP BY label,frame,s.state ORDER BY label,frame,ms DESC;")
print(f"SELECT label,frame,(b-a)/1e6 interval_ms,SUM(MIN(s.ts+s.dur,b)-MAX(s.ts,a))/1e6 accounted_ms FROM wave_windows JOIN thread_state s ON s.ts<b AND s.ts+s.dur>a JOIN thread t USING(utid) JOIN process p USING(upid) WHERE p.name='com.ridge.game' AND t.tid={args.tid} GROUP BY label,frame;")

#!/usr/bin/env python3
"""Describe live fixture coverage and per-segment frame costs, never feel approval.

The v3 fixture resets at explicit 12-second boundaries. Export start_phase is
derived after trimming partial frames; exclude 0.1 s near boundaries when
classifying performance. Keep every tail separately in the main report.
"""
import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

def rows(path):
    with path.open() as stream:
        return [{key: float(value) for key, value in row.items()} for row in csv.DictReader(stream)]

def p95(values):
    return sorted(values)[max(0, math.ceil(len(values) * .95) - 1)]

directory = Path(sys.argv[1])
metadata = json.loads((directory / "metadata.json").read_text())
assert metadata["options"]["fixture"] == "live"
hz = int(metadata["physics_hz"])
results = json.loads((directory / "summary.json").read_text())
names = ["entry_initial_3", "entry_initial_8", "entry_initial_15", "reverse_initial_8",
         "current_deep", "calm_deep", "initialized_stall_exit", "shallow"]
print("# Live fixture coverage (initial speeds in m/s; ordinary forces thereafter)\n")
print("Nominal phase classification excludes 0.1 s around each reset boundary.")
print("Exit deliberately initializes a stalled state; other stalls below are naturally earned.")
print("These are scripted trajectories, not owner feel acceptance or matched GPU views.\n")
print("| Case / segment | Ticks | Immersion min–max | Flood max | Stalled ticks/end | Max packets | xyz excursion m | Water p95 ms |")
print("| --- | --- | --- | --- | --- | --- | --- | --- |")
for result in results:
    ticks = rows(directory / (result["case"] + "_ticks.csv"))
    frames = {int(row["process_frame"]): row for row in rows(directory / (result["case"] + "_frames.csv"))}
    groups = defaultdict(list)
    membership = defaultdict(set)
    for index, tick in enumerate(ticks):
        phase = int(result["start_phase"]) + index
        within = phase % (hz * 12)
        if within < hz * .1 or within >= hz * 11.9:
            continue
        kind = phase // (hz * 12) % 8
        groups[kind].append(tick)
        membership[int(tick["process_frame"])].add(kind)
    assert set(groups) == set(range(8)), result["case"] + " misses a segment"
    for kind in range(8):
        subset = groups[kind]
        values = [frames[frame]["total_upper_usec"] / 1000 for frame, kinds in membership.items() if kinds == {kind}]
        excursion = [max(row[axis] for row in subset) - min(row[axis] for row in subset) for axis in ("x", "y", "z")]
        print(f"| {result['case']} / {names[kind]} | {len(subset)} | "
              f"{min(t['immersion'] for t in subset):.3f}–{max(t['immersion'] for t in subset):.3f} | "
              f"{max(t['flooding'] for t in subset):.3f} | {sum(t['stalled'] > 0 for t in subset)}/{int(subset[-1]['stalled'])} | "
              f"{max(t['packets'] for t in subset):.0f} | {' / '.join(f'{v:.3f}' for v in excursion)} | {p95(values):.3f} |")


## final_live: {'car': 'all', 'fixture': 'live', 'modes': '0,1,2', 'rounds': 1.0, 'seconds': 108.0, 'settle_seconds': 10.0, 'tag': 'final_live', 'warm_seconds': 60.0}

CPU policy: Test Ground 6/7 ms p95/p99. Modes: 0 Off, 1 Car waves, 2 Full, 3 debug refined-flat.

Feedback scope: water regions incl. shared wet spray/mixed tyre audio; whole mixed upper bound retained separately 

| Case | Water p95/p99 ms | CPU | Frame p95/p99 ms | FPS | Frame | Max ms / tails | GPU p95 | Draws / primitives max | Setup ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| offroad_4x4_r0_o0_m0 | 2.310/2.448 | PASS | 17.392/17.977 | 60.003 | PASS | 20.240 / 0 | 8.618 | 79 / 215599 | 56.136 |
| offroad_4x4_r0_o1_m1 | 4.969/5.173 | PASS | 17.467/18.425 | 60.007 | PASS | 35.656 / 1 | 9.127 | 82 / 239837 | 56.136 |
| offroad_4x4_r0_o2_m2 | 4.885/5.121 | PASS | 17.411/18.212 | 60.011 | PASS | 29.288 / 0 | 9.138 | 82 / 239837 | 56.136 |
| rally_r0_o0_m0 | 2.314/2.451 | PASS | 17.314/17.739 | 60.013 | PASS | 21.990 / 0 | 8.380 | 79 / 215143 | 69.173 |
| rally_r0_o1_m1 | 4.949/5.168 | PASS | 17.477/18.337 | 60.011 | PASS | 27.105 / 0 | 8.838 | 82 / 239381 | 69.173 |
| rally_r0_o2_m2 | 4.881/5.135 | PASS | 17.449/18.283 | 60.012 | PASS | 23.247 / 0 | 8.781 | 82 / 239381 | 69.173 |
| rally_tuned_r0_o0_m0 | 2.324/2.484 | PASS | 17.332/17.807 | 60.012 | PASS | 27.324 / 0 | 8.885 | 79 / 215215 | 64.769 |
| rally_tuned_r0_o1_m1 | 4.948/5.169 | PASS | 17.434/18.304 | 60.014 | PASS | 22.165 / 0 | 9.359 | 82 / 239453 | 64.769 |
| rally_tuned_r0_o2_m2 | 4.905/5.125 | PASS | 17.441/18.168 | 60.013 | PASS | 24.601 / 0 | 9.323 | 82 / 239453 | 64.769 |

Matched-case GPU p95 differences versus Off (unchanged +0.50 ms allocation):
LIVE trajectories differ: these differences are descriptive, NOT matched-pose GPU acceptance.
- offroad_4x4 round 0 mode 1: +0.509 ms (outside/unavailable); valid=True
- offroad_4x4 round 0 mode 2: +0.520 ms (outside/unavailable); valid=True
- rally round 0 mode 1: +0.458 ms (inside); valid=True
- rally round 0 mode 2: +0.401 ms (inside); valid=True
- rally_tuned round 0 mode 1: +0.474 ms (inside); valid=True
- rally_tuned round 0 mode 2: +0.438 ms (inside); valid=True

Retained >33.3 ms frame/tick records (correlation only, not cause):
[
  {
    "case": "offroad_4x4_r0_o1_m1",
    "frame": {
      "process_frame": 12667.0,
      "frame_usec": 35656.0,
      "physics_ticks": 2.0,
      "controller_usec": 1594.0,
      "runtime_usec": 224.0,
      "emitter_usec": 173.0,
      "coordinator_usec": 38.0,
      "effects_upper_usec": 93.0,
      "audio_upper_usec": 26.0,
      "hud_usec": 22.0,
      "flat_usec": 0.0,
      "total_upper_usec": 2170.0,
      "wave_query_usec": 390.0,
      "gpu_ms": 8.64400005340576,
      "render_cpu_ms": 0.4379999935627,
      "draws": 45.0,
      "primitives": 38941.0,
      "effects_all_usec": 159.0,
      "audio_all_usec": 80.0,
      "total_mixed_upper_usec": 2290.0,
      "end_usec": 215713817.0
    },
    "ticks": [
      {
        "process_frame": 12667.0,
        "physics_tick": 25353.0,
        "controller_usec": 1192.0,
        "runtime_usec": 132.0,
        "emitter_usec": 97.0,
        "coordinator_usec": 34.0,
        "wave_query_usec": 242.0,
        "immersion": 1.0,
        "flooding": 0.56458333333335,
        "stalled": 0.0,
        "vertices": 18.0,
        "packets": 1.0,
        "x": 105.026847839355,
        "y": 1.9499853849411,
        "z": 90.134033203125,
        "velocity_x": 0.00029801449273,
        "velocity_y": -0.02036019787192,
        "velocity_z": 0.01100055873394
      },
      {
        "process_frame": 12667.0,
        "physics_tick": 25354.0,
        "controller_usec": 402.0,
        "runtime_usec": 92.0,
        "emitter_usec": 76.0,
        "coordinator_usec": 4.0,
        "wave_query_usec": 148.0,
        "immersion": 1.0,
        "flooding": 0.56562500000002,
        "stalled": 0.0,
        "vertices": 18.0,
        "packets": 1.0,
        "x": 105.026847839355,
        "y": 1.94980669021606,
        "z": 90.1341247558594,
        "velocity_x": 0.00027194747236,
        "velocity_y": -0.02142500504851,
        "velocity_z": 0.01066459622234
      }
    ],
    "clock_anchor": {
      "after_usec": 192808069,
      "before_usec": 192808065,
      "unix": 1790339986.07084
    }
  }
]
